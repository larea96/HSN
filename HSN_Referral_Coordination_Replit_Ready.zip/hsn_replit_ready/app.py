
from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify, send_from_directory
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
import sqlite3, os, uuid
from datetime import datetime

BASE=os.path.dirname(os.path.abspath(__file__))
DB=os.path.join(BASE,"hsn.db")
UPLOAD=os.path.join(BASE,"uploads")
os.makedirs(UPLOAD,exist_ok=True)
app=Flask(__name__)
app.secret_key="HSN-DEMO-ONLY-CHANGE-IN-PRODUCTION"
app.config["MAX_CONTENT_LENGTH"]=15*1024*1024
ALLOWED={"pdf","png","jpg","jpeg","doc","docx"}

def db():
    c=sqlite3.connect(DB)
    c.row_factory=sqlite3.Row
    c.execute("PRAGMA foreign_keys=ON")
    return c
def now(): return datetime.now().strftime("%Y-%m-%d %H:%M:%S")
def q(sql,args=(),one=False):
    c=db(); r=c.execute(sql,args); out=r.fetchone() if one else r.fetchall(); c.close(); return out

SCHEMA="""
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE, password TEXT, name TEXT, role TEXT, agency_id INTEGER);
CREATE TABLE IF NOT EXISTS agencies(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,county TEXT,ami TEXT,active INTEGER DEFAULT 1);
CREATE TABLE IF NOT EXISTS programs(id INTEGER PRIMARY KEY AUTOINCREMENT,agency_id INTEGER,service TEXT);
CREATE TABLE IF NOT EXISTS requirements(id INTEGER PRIMARY KEY AUTOINCREMENT,program_id INTEGER,document_name TEXT);
CREATE TABLE IF NOT EXISTS clients(id INTEGER PRIMARY KEY AUTOINCREMENT,client_code TEXT UNIQUE,name TEXT,county TEXT,ami TEXT);
CREATE TABLE IF NOT EXISTS referrals(id INTEGER PRIMARY KEY AUTOINCREMENT,ref_code TEXT UNIQUE,client_id INTEGER,service TEXT,created_by INTEGER,status TEXT,created_at TEXT);
CREATE TABLE IF NOT EXISTS referral_agencies(id INTEGER PRIMARY KEY AUTOINCREMENT,referral_id INTEGER,agency_id INTEGER,status TEXT,reason TEXT,updated_at TEXT);
CREATE TABLE IF NOT EXISTS documents(id INTEGER PRIMARY KEY AUTOINCREMENT,referral_id INTEGER,document_name TEXT,filename TEXT,uploaded_by INTEGER,uploaded_at TEXT);
CREATE TABLE IF NOT EXISTS events(id INTEGER PRIMARY KEY AUTOINCREMENT,referral_id INTEGER,user_id INTEGER,event TEXT,detail TEXT,created_at TEXT);
CREATE TABLE IF NOT EXISTS notifications(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER,referral_id INTEGER,message TEXT,is_read INTEGER DEFAULT 0,created_at TEXT);
"""
def init_db():
    c=db(); c.executescript(SCHEMA)
    if c.execute("SELECT COUNT(*) FROM users").fetchone()[0]==0:
        agencies=[
          ("Sunrise Housing Collaborative","Orange","≤80%"),
          ("Central Florida Stability Network","Seminole","≤60%"),
          ("Neighborhood Bridge Assistance","Osceola","≤80%"),
          ("Pathway Relief Services","Orange","≤50%")]
        for a in agencies: c.execute("INSERT INTO agencies(name,county,ami) VALUES(?,?,?)",a)
        services={
          1:{"Rental Assistance":["Photo ID","Lease / Rental Agreement","Income Verification","Past-Due Notice"],"Move-In Assistance":["Photo ID","Lease / Rental Agreement","Income Verification","Landlord Move-In Quote"]},
          2:{"Rental Assistance":["Photo ID","Lease / Rental Agreement","Income Verification","Eviction Notice"],"Relocation":["Photo ID","Income Verification","Destination Address","Relocation Quote"]},
          3:{"Rental Assistance":["Photo ID","Income Verification","Past-Due Notice"],"Move-In Assistance":["Photo ID","Lease / Rental Agreement","Income Verification","Move-In Cost Sheet"],"Hotel Assistance":["Photo ID","Income Verification","Homelessness Verification","Hotel Quote"]},
          4:{"Hotel Assistance":["Photo ID","Income Verification","Homelessness Verification"],"Relocation":["Photo ID","Income Verification","Destination Address"]}
        }
        for aid,svcs in services.items():
            for s,docs in svcs.items():
                cur=c.execute("INSERT INTO programs(agency_id,service) VALUES(?,?)",(aid,s)); pid=cur.lastrowid
                for d in docs: c.execute("INSERT INTO requirements(program_id,document_name) VALUES(?,?)",(pid,d))
        users=[
          ("caseworker","demo123","Alex Morgan","referrer",None),
          ("sunrise","demo123","Jordan Lee","agency",1),
          ("stability","demo123","Taylor Brooks","agency",2),
          ("bridge","demo123","Casey Rivera","agency",3),
          ("pathway","demo123","Morgan Ellis","agency",4),
          ("admin","admin123","HSN Demo Administrator","admin",None)]
        for u in users:c.execute("INSERT INTO users(username,password,name,role,agency_id) VALUES(?,?,?,?,?)",(u[0],generate_password_hash(u[1]),u[2],u[3],u[4]))
        clients=[("CL-DEMO-001","Jamie Carter","Orange","≤80%"),("CL-DEMO-002","Riley Thomas","Seminole","≤60%"),("CL-DEMO-003","Avery Johnson","Osceola","≤80%")]
        for x in clients:c.execute("INSERT INTO clients(client_code,name,county,ami) VALUES(?,?,?,?)",x)
    c.commit(); c.close()
init_db()

def user(): return q("SELECT * FROM users WHERE id=?",(session.get("uid"),),one=True)
def login_required(fn):
    from functools import wraps
    @wraps(fn)
    def w(*a,**kw):
        if not session.get("uid"): return redirect(url_for("login"))
        return fn(*a,**kw)
    return w
def event(ref,user_id,event,detail=""):
    c=db(); c.execute("INSERT INTO events(referral_id,user_id,event,detail,created_at) VALUES(?,?,?,?,?)",(ref,user_id,event,detail,now())); c.commit(); c.close()
def notify(ref,uid,msg):
    c=db(); c.execute("INSERT INTO notifications(user_id,referral_id,message,created_at) VALUES(?,?,?,?)",(uid,ref,msg,now())); c.commit(); c.close()

@app.context_processor
def globals():
    u=user(); n=q("SELECT COUNT(*) n FROM notifications WHERE user_id=? AND is_read=0",(u["id"],),one=True)["n"] if u else 0
    return {"me":u,"unread":n}

@app.route("/")
@login_required
def dashboard():
    u=user()
    if u["role"]=="agency": return redirect(url_for("inbox"))
    refs=q("""SELECT r.*,c.name client_name,c.client_code FROM referrals r JOIN clients c ON c.id=r.client_id ORDER BY r.id DESC""")
    return render_template("dashboard.html",refs=refs)

@app.route("/login",methods=["GET","POST"])
def login():
    if request.method=="POST":
        u=q("SELECT * FROM users WHERE username=?",(request.form["username"],),one=True)
        if u and check_password_hash(u["password"],request.form["password"]):
            session["uid"]=u["id"]; return redirect(url_for("dashboard"))
        flash("Invalid demo username or password.","error")
    return render_template("login.html")

@app.route("/logout")
def logout(): session.clear(); return redirect(url_for("login"))

@app.route("/referral/new",methods=["GET","POST"])
@login_required
def new_referral():
    if request.method=="POST":
        service=request.form["service"]; client_id=request.form["client_id"]; agency_ids=request.form.getlist("agency_ids")
        if not agency_ids: flash("Select at least one agency.","error"); return redirect(url_for("new_referral"))
        client=q("SELECT * FROM clients WHERE id=?",(client_id,),one=True)
        refcode="RF-DEMO-"+uuid.uuid4().hex[:6].upper()
        c=db(); cur=c.execute("INSERT INTO referrals(ref_code,client_id,service,created_by,status,created_at) VALUES(?,?,?,?,?,?)",(refcode,client_id,service,user()["id"],"Submitted",now())); rid=cur.lastrowid
        for aid in agency_ids:c.execute("INSERT INTO referral_agencies(referral_id,agency_id,status,updated_at) VALUES(?,?,?,?)",(rid,aid,"Submitted",now()))
        c.commit(); c.close()
        event(rid,user()["id"],"Referral submitted",f"Sent to {len(agency_ids)} qualifying agencies.")
        for aid in agency_ids:
            us=q("SELECT id FROM users WHERE agency_id=? AND role='agency'",(aid,))
            for x in us: notify(rid,x["id"],f"New qualifying {service} referral: {client['name']} ({refcode}).")
        return redirect(url_for("referral",rid=rid))
    services=sorted(set(x["service"] for x in q("SELECT service FROM programs")))
    clients=q("SELECT * FROM clients ORDER BY name")
    return render_template("new.html",services=services,clients=clients)

@app.route("/api/agencies")
@login_required
def api_agencies():
    service=request.args.get("service","")
    rows=q("""SELECT DISTINCT a.* FROM agencies a JOIN programs p ON p.agency_id=a.id WHERE p.service=? AND a.active=1 ORDER BY a.name""",(service,))
    out=[]
    for a in rows:
        docs=q("""SELECT r.document_name FROM requirements r JOIN programs p ON p.id=r.program_id WHERE p.agency_id=? AND p.service=?""",(a["id"],service))
        out.append(dict(a)|{"docs":[x["document_name"] for x in docs]})
    return jsonify(out)

@app.route("/referral/<int:rid>")
@login_required
def referral(rid):
    r=q("""SELECT r.*,c.name client_name,c.client_code,c.county,c.ami,u.name creator FROM referrals r JOIN clients c ON c.id=r.client_id JOIN users u ON u.id=r.created_by WHERE r.id=?""",(rid,),one=True)
    if not r: return "Not found",404
    ra=q("""SELECT ra.*,a.name agency_name FROM referral_agencies ra JOIN agencies a ON a.id=ra.agency_id WHERE ra.referral_id=?""",(rid,))
    docs=q("SELECT * FROM documents WHERE referral_id=? ORDER BY id",(rid,))
    ev=q("SELECT e.*,u.name FROM events e JOIN users u ON u.id=e.user_id WHERE e.referral_id=? ORDER BY e.id DESC",(rid,))
    return render_template("referral.html",r=r,ra=ra,docs=docs,events=ev)

@app.route("/referral/<int:rid>/upload",methods=["POST"])
@login_required
def upload(rid):
    name=request.form["document_name"]; f=request.files.get("file")
    if not f or not f.filename: flash("Choose a file.","error"); return redirect(url_for("referral",rid=rid))
    ext=f.filename.rsplit(".",1)[-1].lower() if "." in f.filename else ""
    if ext not in ALLOWED: flash("File type not allowed in demo.","error"); return redirect(url_for("referral",rid=rid))
    fn=secure_filename(f.filename); stored=f"{uuid.uuid4().hex}_{fn}"; f.save(os.path.join(UPLOAD,stored))
    c=db(); c.execute("INSERT INTO documents(referral_id,document_name,filename,uploaded_by,uploaded_at) VALUES(?,?,?,?,?)",(rid,name,stored,user()["id"],now())); c.commit(); c.close()
    event(rid,user()["id"],"Document uploaded",name); flash("Document uploaded.","success"); return redirect(url_for("referral",rid=rid))

@app.route("/inbox")
@login_required
def inbox():
    u=user()
    if u["role"]!="agency": return redirect(url_for("dashboard"))
    refs=q("""SELECT r.*,c.name client_name,c.client_code,c.county,c.ami,ra.id ra_id,ra.status ra_status,ra.reason
              FROM referrals r JOIN clients c ON c.id=r.client_id JOIN referral_agencies ra ON ra.referral_id=r.id
              WHERE ra.agency_id=? ORDER BY r.id DESC""",(u["agency_id"],))
    return render_template("inbox.html",refs=refs,agency=q("SELECT * FROM agencies WHERE id=?",(u["agency_id"],),one=True))

@app.route("/referral/<int:rid>/agency-action",methods=["POST"])
@login_required
def agency_action(rid):
    u=user()
    if u["role"]!="agency": return "Forbidden",403
    action=request.form["action"]; reason=request.form.get("reason","").strip()
    r=q("SELECT * FROM referrals WHERE id=?",(rid,),one=True)
    ra=q("SELECT * FROM referral_agencies WHERE referral_id=? AND agency_id=?",(rid,u["agency_id"]),one=True)
    if not r or not ra:return "Not found",404
    c=db()
    if action=="select":
        winner=q("""SELECT * FROM referral_agencies WHERE referral_id=? AND status IN ('Selected','In Processing','Approved','Check Ready')""",(rid,),one=True)
        if winner: flash("Another agency already selected this client. Referral is locked.","error")
        else:
            c.execute("UPDATE referral_agencies SET status='Selected',updated_at=? WHERE id=?",(now(),ra["id"]))
            c.execute("UPDATE referrals SET status='Selected' WHERE id=?",(rid,))
            c.commit(); event(rid,u["id"],"Agency selected client",f"{u['name']} selected the client. Other agencies are locked.")
            creator=q("SELECT created_by FROM referrals WHERE id=?",(rid,),one=True); notify(rid,creator["created_by"],"Your referral was selected by the receiving agency.")
            flash("Client selected. Other agencies are now locked.","success")
    elif action=="decline":
        if not reason: flash("A decline reason is required.","error"); return redirect(url_for("inbox"))
        c.execute("UPDATE referral_agencies SET status='Declined',reason=?,updated_at=? WHERE id=?",(reason,now(),ra["id"])); c.commit()
        event(rid,u["id"],"Agency declined referral",f"{u['name']}: {reason}")
        creator=q("SELECT created_by FROM referrals WHERE id=?",(rid,),one=True); notify(rid,creator["created_by"],f"Referral declined: {reason}")
        flash("Referral declined. Other agencies remain eligible.","success")
    elif action in ("process","approve","deny","check"):
        current=ra["status"]
        if action=="process": ns="In Processing"; label="Application in processing"
        elif action=="approve": ns="Approved"; label="Application approved"
        elif action=="deny":
            if not reason: flash("A denial reason is required.","error"); return redirect(url_for("inbox"))
            ns="Denied"; label="Application denied"
        else: ns="Check Ready"; label="Check is ready"
        c.execute("UPDATE referral_agencies SET status=?,reason=?,updated_at=? WHERE id=?",(ns,reason,now(),ra["id"]))
        c.execute("UPDATE referrals SET status=? WHERE id=?",(ns,rid)); c.commit()
        event(rid,u["id"],label,f"{u['name']} updated status to {ns}."+ (f" Reason: {reason}" if reason else ""))
        creator=q("SELECT created_by FROM referrals WHERE id=?",(rid,),one=True); notify(rid,creator["created_by"],f"{label} for referral {r['ref_code']}.")
        if action=="deny":
            c=db(); c.execute("UPDATE referrals SET status='Denied' WHERE id=?",(rid,)); c.commit(); c.close()
        flash(f"Referral updated: {ns}.","success")
    return redirect(url_for("inbox"))

@app.route("/notifications")
@login_required
def notifications():
    u=user(); rows=q("SELECT n.*,r.ref_code FROM notifications n LEFT JOIN referrals r ON r.id=n.referral_id WHERE n.user_id=? ORDER BY n.id DESC",(u["id"],))
    c=db(); c.execute("UPDATE notifications SET is_read=1 WHERE user_id=?",(u["id"],)); c.commit(); c.close()
    return render_template("notifications.html",rows=rows)

@app.route("/files/<path:name>")
@login_required
def files(name): return send_from_directory(UPLOAD,name,as_attachment=True)

@app.route("/admin")
@login_required
def admin():
    if user()["role"]!="admin": return redirect(url_for("dashboard"))
    agencies=q("SELECT * FROM agencies ORDER BY name"); users=q("SELECT u.*,a.name agency_name FROM users u LEFT JOIN agencies a ON a.id=u.agency_id ORDER BY u.role,u.name")
    return render_template("admin.html",agencies=agencies,users=users)

if __name__=="__main__":
    app.run(debug=True,host="0.0.0.0",port=5000)
