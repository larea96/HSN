# HSN Referral Coordination — Browser Development Version

This package is prepared for a browser-based development environment such as Replit.

## Replit setup
1. Create a new Replit project.
2. Choose **Import from ZIP** (or upload the files from this ZIP into a new project).
3. Upload this ZIP.
4. Replit should detect the Python project. If it asks for a run command, use:
   `python app.py`
5. Click **Run**.
6. Open the web preview. The HSN app should load in the browser.

## Demo accounts
- Referring case manager: `caseworker` / `demo123`
- Sunrise Housing Collaborative: `sunrise` / `demo123`
- Central Florida Stability Network: `stability` / `demo123`
- Neighborhood Bridge Assistance: `bridge` / `demo123`
- Pathway Relief Services: `pathway` / `demo123`
- HSN administrator: `admin` / `admin123`

## What to test
1. Log in as `caseworker`.
2. Create a referral using fictional client information.
3. Select multiple qualifying agencies.
4. Upload the demo documents.
5. Submit the referral.
6. Open another browser/private window and log in as `sunrise`.
7. Open a second browser/private window and log in as `stability`.
8. Have one agency select the referral and verify the other agency is locked out.
9. Move the selected referral through **In Processing → Approved → Check Ready**.
10. Return to the caseworker account and verify the notifications and timeline.

## Important
This is still a development/demo application. Use fictional information only. Do not enter real client information.

The next development pass should enforce the required-document gate before referral submission, add stronger concurrent locking, production authentication, encrypted document storage, audit/security controls, and real notifications.
