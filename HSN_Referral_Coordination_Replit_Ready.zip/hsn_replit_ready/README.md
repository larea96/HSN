# HSN Referral Coordination — Multi-User Demo

A local, fictional-data test application for the HSN referral workflow.

## Start
1. Install Python 3.10+.
2. In this folder run:
   `python -m venv .venv`
3. Activate it:
   - macOS/Linux: `source .venv/bin/activate`
   - Windows: `.venv\Scripts\activate`
4. Install dependencies:
   `pip install -r requirements.txt`
5. Start:
   `python app.py`
6. Open:
   `http://127.0.0.1:5000`

## Demo accounts
- Referring case manager: `caseworker` / `demo123`
- Sunrise Housing Collaborative: `sunrise` / `demo123`
- Central Florida Stability Network: `stability` / `demo123`
- Neighborhood Bridge Assistance: `bridge` / `demo123`
- Pathway Relief Services: `pathway` / `demo123`
- HSN administrator: `admin` / `admin123`

## Test the first-selection lock
1. Log in as `caseworker` and create a referral for a service that has multiple agencies.
2. Open a second browser/private window and log in as `sunrise`.
3. Open another private window and log in as `stability`.
4. Both agency users can see the referral.
5. Have one agency click Select.
6. The other agency will not be able to select because the referral is locked.
7. Continue Selected -> In Processing -> Approved -> Check Ready.
8. Log back in as caseworker to see notifications/timeline.

## Safety
This is a development/demo application only. It uses fictional names and data. Do not enter real client information. It is not production-ready and has not been security, privacy, compliance, or penetration tested.

## Important next production work
- Production secret management and HTTPS
- PostgreSQL or approved HSN database
- Strong authentication/SSO and MFA
- Role/permission matrix
- Server-side required-document enforcement before submission
- Encrypted document storage with access controls
- Immutable audit logs
- Virus/malware scanning for uploads
- Data retention/deletion policy
- CSRF protection and additional security hardening
- Formal privacy/security/compliance review
- Email/SMS notification provider
- Concurrent transaction locking at database level for first-selection-wins
- ClientTrack integration after HSN confirms supported API/integration method
